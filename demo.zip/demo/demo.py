import scrapy
import sys

reload(sys)
sys.setdefaultencoding('utf-8')


class ShareditorSpider(scrapy.Spider):
    name = "xywyclub"
    allowed_domains = ["xywy.com"]
    start_urls = [
        "http://3g.club.xywy.com/wkeshi/2016-09-24/2.html"
    ]

    def parse(self, response):

        for i in range(1, 900):
            url = 'http://3g.club.xywy.com/wkeshi/2016-09-24/%s.html' % i
            request = scrapy.Request(url, callback=self.parse_detail2)
            yield request

    def parse_detail2(self, response):
        hrefs = response.selector.xpath('//h4/em/a/@href').extract()
        for href in hrefs:
            print "processing: ", href
            request = scrapy.Request(href, callback=self.parse_detail)
            yield request

        filename = response.url.split("/")[-2] + '.html'

    def parse_detail(self, response):
        f = open("sentences.txt", 'a')
        ask = response.selector.xpath('//div[contains(@id, "qdetailc")]/text()').extract()[0].replace("\n", "")
        print "ask: ", ask
        f.write('\n')
        f.write(ask)

        reply = response.selector.xpath('//div[contains(@class, "pt10 btn-a lh180 f13")]/text()').extract()[0].replace(
            "\n", "")
        print "reply: ", reply
        f.write('\n')
        f.write(reply)
        f.close()
